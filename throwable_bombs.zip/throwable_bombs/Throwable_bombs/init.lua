local modname = minetest.get_current_modname()
local modpath = minetest.get_modpath(modname)

dofile(modpath.."/bomb.lua")
dofile(modpath.."/dungeon_master.lua")
dofile(modpath.."/tnt_stick.lua")
